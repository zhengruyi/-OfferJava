package Q48_不能被继承的类;

/**
 * @author Ruyi ZHENG
 * @version 1.00
 * @time 30/04/2020 11:58
 **/

final public class Test {
    // java 中只需要加上 final 关键字就可以实现类不可被继承
    // C++ 中相对复杂
}
